# Real Client Mod — by Real_Player_11
### Minecraft 1.21.4 | Fabric Mod

---

## Come compilare e installare

### Requisiti
- Java JDK 21 (https://adoptium.net/)
- Fabric Loader installato su Minecraft 1.21.4

---

### PASSO 1 — Scarica il Gradle Wrapper
Apri il terminale nella cartella del progetto ed esegui:

**Windows (PowerShell):**
```
.\gradlew.bat build
```
**Mac / Linux:**
```
./gradlew build
```

*(La prima volta scarica tutto automaticamente, ci vuole qualche minuto)*

---

### PASSO 2 — Trova il file .jar
Dopo la compilazione trovi il file in:
```
build/libs/realclient-1.0.0.jar
```

---

### PASSO 3 — Installa la mod
1. Apri la cartella `.minecraft`
   - Windows: `%appdata%\.minecraft\mods\`
   - Mac: `~/Library/Application Support/minecraft/mods/`
2. Copia `realclient-1.0.0.jar` dentro la cartella `mods`
3. Assicurati di avere **Fabric Loader** e **Fabric API** installati
4. Avvia Minecraft con il profilo Fabric 1.21.4

---

### PASSO 4 — Fabric API
Scarica Fabric API qui: https://modrinth.com/mod/fabric-api
Mettila anch'essa nella cartella `mods`.

---

## Cosa fa la mod
- Sostituisce la schermata principale con il tema **Real Client**
- Colori: viola / nero / bianco
- Logo con la lettera "R" (sostituibile con la tua immagine)
- Bottoni: Giocatore Singolo, Multigiocatore, Opzioni, Cosmetici, Negozio, Esci
- Username "REAL_PLAYER_11" nella topbar
- Griglia viola sullo sfondo

---

## Struttura del progetto
```
realclient/
├── build.gradle
├── gradle.properties
├── settings.gradle
└── src/main/
    ├── java/net/realplayer11/realclient/
    │   ├── RealClientMod.java          ← Entry point
    │   └── mixin/
    │       └── TitleScreenMixin.java   ← Tutto il rendering
    └── resources/
        ├── fabric.mod.json
        └── realclient.mixins.json
```

---

Creato da Claude per Real_Player_11 🟣
